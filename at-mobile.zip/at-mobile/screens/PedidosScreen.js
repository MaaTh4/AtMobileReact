import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

const PedidosScreen = ({ orders }) => {
  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <Text style={styles.itemTitle}>{item.name}</Text>
      <Text style={styles.itemDetail}>Quantidade: {item.quantity}</Text>
      <Text style={styles.itemDetail}>Preço: R$ {(item.price * item.quantity).toFixed(2)}</Text>
      <Text style={styles.itemDetail}>Endereço: {item.address}</Text>
      <Text style={styles.itemDetail}>Método de pagamento: {item.paymentMethod}</Text>
      <Text style={styles.itemDetail}>
        Data do pedido: {new Date(item.orderDate).toLocaleString()}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Meus Pedidos</Text>
      {orders.length === 0 ? (
        <Text style={styles.emptyMessage}>Você ainda não tem pedidos.</Text>
      ) : (
        <FlatList
          data={orders}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: '#f8f9fa',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#343a40',
  },
  emptyMessage: {
    fontSize: 18,
    color: '#888',
    textAlign: 'center',
    marginTop: 20,
  },
  itemContainer: {
    backgroundColor: '#fff',
    padding: 15,
    marginBottom: 15,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  itemTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#343a40',
    marginBottom: 10,
  },
  itemDetail: {
    fontSize: 16,
    color: '#495057',
    marginBottom: 5,
  },
});

export default PedidosScreen;
