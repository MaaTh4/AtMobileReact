import React from 'react';
import { View, Text, StyleSheet, FlatList, Button } from 'react-native';

const ProductsScreen = ({ route, products, addToCart }) => {
  const { category } = route.params;
  const categoryProducts = products[category] || [];

  const renderProduct = ({ item }) => (
    <View style={styles.productItem}>
      <Text style={styles.productName}>{item.name}</Text>
      <Text style={styles.productPrice}>R$ {item.price.toFixed(2)}</Text>
      <Button title="Adicionar ao Carrinho" onPress={() => addToCart(item)} />
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Produtos: {category}</Text>
      {categoryProducts.length > 0 ? (
        <FlatList
          data={categoryProducts}
          keyExtractor={(item) => item.id}
          renderItem={renderProduct}
        />
      ) : (
        <Text style={styles.emptyMessage}>Nenhum produto disponível.</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  productItem: {
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#f9f9f9',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  productName: {
    fontSize: 18,
    marginBottom: 5,
  },
  productPrice: {
    fontSize: 16,
    marginBottom: 10,
    color: '#888',
  },
  emptyMessage: {
    fontSize: 16,
    textAlign: 'center',
    color: '#555',
  },
});

export default ProductsScreen;
